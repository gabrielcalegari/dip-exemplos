using System;
using DependencyInversionPrinciple.Web.Cases.Reports;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;

namespace DependencyInversionPrinciple.Web.Controllers
{
    public class ServiceLocatorController : ApiController
    {
        private IServiceProvider ServiceProvider { get; }

        public ServiceLocatorController(IServiceProvider serviceProvider)
        {
            this.ServiceProvider = serviceProvider;
        }

        [HttpGet]
        public IActionResult Get()
        {
            string report = $"Report {DateTime.Now.ToString()}";

            var reportService = ServiceProvider.GetService<IReportService>();
            reportService.Send(report);

            return Ok();
        }
    }
}