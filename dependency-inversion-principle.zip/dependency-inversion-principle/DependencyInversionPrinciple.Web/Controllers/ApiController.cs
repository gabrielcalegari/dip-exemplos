using Microsoft.AspNetCore.Mvc;

namespace DependencyInversionPrinciple.Web.Controllers
{
    [Route("[controller]")]
    public class ApiController : ControllerBase
    {
    }
}