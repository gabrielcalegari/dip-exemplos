using System;
using DependencyInversionPrinciple.Web.Cases.Reports;
using Microsoft.AspNetCore.Mvc;

namespace DependencyInversionPrinciple.Web.Controllers
{
    public class Reports2Controller : ApiController
    {
        [HttpGet]
        public IActionResult Get([FromServices] IReportService reportService)
        {
            string report = $"Report {DateTime.Now.ToString()}";
            
            reportService.Send(report);

            return Ok();
        }
    }
}