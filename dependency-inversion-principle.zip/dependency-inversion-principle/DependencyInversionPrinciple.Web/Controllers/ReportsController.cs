using System;
using DependencyInversionPrinciple.Web.Cases.Reports;
using Microsoft.AspNetCore.Mvc;

namespace DependencyInversionPrinciple.Web.Controllers
{
    public class ReportsController : ApiController
    {
        public IReportService ReportService { get; }
        
        public ReportsController(IReportService reportService)
        {
            this.ReportService = reportService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            string report = $"Report {DateTime.Now.ToString()}";
            
            ReportService.Send(report);

            return Ok();
        }
    }
}