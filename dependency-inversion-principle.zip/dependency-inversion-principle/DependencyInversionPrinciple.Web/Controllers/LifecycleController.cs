using System;
using DependencyInversionPrinciple.Web.Cases.Lifecycle;
using Microsoft.AspNetCore.Mvc;

namespace DependencyInversionPrinciple.Web.Controllers
{
    public class LifecycleController : ApiController
    {
        private IPhotoService PhotoService { get; }
        private IPhotoService PhotoService2 { get; }

        public LifecycleController(IPhotoService photoService, IPhotoService photoService2) 
        {
            this.PhotoService = photoService;
            this.PhotoService2 = photoService2;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var concretePhotoService = PhotoService as PhotoService;
            var concretePhotoService2 = PhotoService2 as PhotoService;

            string services = 
                "Primeira instância: " + Environment.NewLine + Environment.NewLine +
                "Transient: " + concretePhotoService.Transient.Id + Environment.NewLine +
                "Scoped: " + concretePhotoService.Scoped.Id + Environment.NewLine +
                "Singleton: " + concretePhotoService.Singleton.Id + Environment.NewLine +

                Environment.NewLine +
                Environment.NewLine +

                "Segunda instância: " + Environment.NewLine + Environment.NewLine +
                "Transient: " + concretePhotoService2.Transient.Id + Environment.NewLine +
                "Scoped: " + concretePhotoService2.Scoped.Id + Environment.NewLine +
                "Singleton: " + concretePhotoService2.Singleton.Id + Environment.NewLine;

            return Ok(services);
        }
    }
}