using System;

namespace DependencyInversionPrinciple.Web.Cases.Reports
{
    public interface IReportPlatform
    {
        void Publish(string body);
    }

    public interface IReportService
    {
        void Send(string body);
    }

    public class ReportService : IReportService
    {
        private IReportPlatform ReportPlatform { get; }

        public ReportService(IReportPlatform reportPlatform)
        {
            this.ReportPlatform = reportPlatform;
        }

        public void Send(string body)
        {
            ReportPlatform.Publish(body);
        }
    }

    public class NewsletterReportPlatform : IReportPlatform
    {
        public void Publish(string body)
        {
            Console.WriteLine("Publicando a Newsletter " + body);

            // Codigo para publicar a newsletter
        }
    }
}