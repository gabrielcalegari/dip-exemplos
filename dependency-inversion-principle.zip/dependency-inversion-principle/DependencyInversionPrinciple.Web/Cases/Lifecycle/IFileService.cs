using System.IO;
using System.Threading.Tasks;

namespace DependencyInversionPrinciple.Web.Cases.Lifecycle
{
    public interface IPhotoService
    {
        Task Save(byte[] photo);
    }

    public class PhotoService : IPhotoService
    {
        public PhotoService(ITransientFileRepository transient, IScopedFileRepository scoped, ISingletonFileRepository singleton)
        {
            this.Transient = transient;
            this.Scoped = scoped;
            this.Singleton = singleton;
        }

        public ITransientFileRepository Transient { get; }
        public IScopedFileRepository Scoped { get; }
        public ISingletonFileRepository Singleton { get; }

        public Task Save(byte[] photo)
        {
            var stream = new MemoryStream(photo);
            return Transient.AddAsync(stream);
        }
    }
}