﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace DependencyInversionPrinciple.Web.Cases.Lifecycle
{
    public interface IFileRepository
    {
        Task AddAsync(Stream file);

        Guid Id { get; }
    }

    public interface ISingletonFileRepository : IFileRepository
    {
    }

    public interface ITransientFileRepository : IFileRepository
    {
    }

    public interface IScopedFileRepository : IFileRepository
    {
    }

    public class FileRepository : ISingletonFileRepository, ITransientFileRepository, IScopedFileRepository
    {
        public FileRepository()
        {
            Id = Guid.NewGuid();
        }

        public Guid Id { get; }

        public Task AddAsync(Stream file)
        {
            throw new NotImplementedException();
        }
    }
}